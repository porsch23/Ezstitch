'use client'

/**
 * app/export/page.tsx
 *
 * Step 5: PDF ready and download.
 *
 * Three states:
 * - idle     → show summary card, "Download PDF" CTA
 * - loading  → generating PDF (lazy-loads @react-pdf/renderer)
 * - done     → success screen with "Make Another Pattern" CTA
 * - error    → friendly error message with retry option
 *
 * The actual PDF generation is fully decoupled — this page just calls
 * downloadPdf() from the pdf-export module and manages the UX around it.
 * The 180kb @react-pdf bundle is only loaded when the user taps Download.
 */

import { useRouter } from 'next/navigation'
import { useState }  from 'react'
import Header         from '@/components/layout/Header'
import StepIndicator  from '@/components/ui/StepIndicator'
import LoadingSpinner from '@/components/ui/LoadingSpinner'
import { usePattern } from '@/context/PatternContext'
import { STITCH_STYLE_META } from '@/lib/constants'

// ─── Inline micro-components ──────────────────────────────────────────────────

function SummaryTile({ label, value }: { label: string; value: string }) {
  return (
    <div style={{
      background:   '#FAF6EF',
      borderRadius: 10,
      padding:      '10px 12px',
      textAlign:    'left',
    }}>
      <div style={{ fontSize: 11, color: '#6B5744', fontFamily: "'DM Sans', sans-serif", marginBottom: 3 }}>
        {label}
      </div>
      <div style={{
        fontFamily: "'Playfair Display', serif",
        fontSize: 17, fontWeight: 700,
        color: '#2C2218',
      }}>
        {value}
      </div>
    </div>
  )
}

// ─── Page component ───────────────────────────────────────────────────────────

type Status = 'idle' | 'loading' | 'done' | 'error'

export default function ExportPage() {
  const router  = useRouter()
  const { state, dispatch } = usePattern()
  const [status, setStatus] = useState<Status>('idle')
  const [error,  setError]  = useState<string | null>(null)

  const { patternData } = state

  async function handleDownload() {
    if (!patternData) return

    setStatus('loading')
    setError(null)

    try {
      // Dynamic import: @react-pdf bundle loads only now
      const { downloadPdf } = await import('@/modules/pdf-export/buildPDF')
      await downloadPdf(patternData, 'my-crochet-pattern', 'My Crochet Pattern')
      setStatus('done')
    } catch (err) {
      console.error('PDF export failed:', err)
      setError(err instanceof Error ? err.message : 'Export failed. Please try again.')
      setStatus('error')
    }
  }

  // ── Loading state ─────────────────────────────────────────────────────────
  if (status === 'loading') {
    return (
      <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: '#FAF6EF' }}>
        <Header />
        <StepIndicator />
        <LoadingSpinner message="Building your PDF…" />
      </main>
    )
  }

  // ── Success state ─────────────────────────────────────────────────────────
  if (status === 'done') {
    return (
      <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: '#FAF6EF' }}>
        <Header />
        <StepIndicator />

        <div style={{
          flex: 1,
          display: 'flex', flexDirection: 'column', alignItems: 'center',
          padding: '32px 28px 180px', textAlign: 'center',
        }}>
          <div style={{
            width: 96, height: 96, borderRadius: 28,
            background: 'rgba(122,158,126,0.15)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 48, marginBottom: 24,
          }}>
            🎉
          </div>

          <h1 style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: 28, fontWeight: 700,
            color: '#2C2218', lineHeight: 1.25, marginBottom: 10,
          }}>
            Pattern downloaded!
          </h1>
          <p style={{
            fontSize: 14, color: '#6B5744', lineHeight: 1.7,
            maxWidth: 280, marginBottom: 28,
            fontFamily: "'DM Sans', sans-serif",
          }}>
            Check your downloads folder. Open the PDF on any device to start crocheting.
          </p>

          {/* What's in the PDF */}
          <div style={{
            width: '100%', maxWidth: 320,
            background: 'white', borderRadius: 20,
            boxShadow: '0 2px 16px rgba(44,34,24,0.07)',
            padding: 16, textAlign: 'left', marginBottom: 16,
          }}>
            <p style={{
              fontSize: 11, fontWeight: 500,
              textTransform: 'uppercase', letterSpacing: '0.08em',
              color: '#6B5744', fontFamily: "'DM Sans', sans-serif",
              marginBottom: 12,
            }}>
              What's in your PDF
            </p>
            {[
              '📐 Full-size pattern grid with row numbers',
              '🎨 Colour key with stitch counts',
              '📖 Step-by-step beginner instructions',
              '🔢 Total stitch count per colour',
            ].map(item => (
              <div key={item} style={{
                fontSize: 13, color: '#2C2218', padding: '9px 0',
                borderBottom: '1px solid #F2EAD8',
                fontFamily: "'DM Sans', sans-serif",
                display: 'flex', gap: 8,
              }}>
                {item}
              </div>
            ))}
          </div>

          <p style={{ fontSize: 13, color: '#C8BFB0', fontFamily: "'DM Sans', sans-serif" }}>
            Happy stitching! 🧶
          </p>
        </div>

        {/* Bottom bar */}
        <div style={{
          position: 'fixed', bottom: 0, left: '50%',
          transform: 'translateX(-50%)',
          width: '100%', maxWidth: 430,
          padding: '16px 20px max(20px, env(safe-area-inset-bottom))',
          background: 'linear-gradient(to top, #FAF6EF 80%, transparent)',
          zIndex: 50, display: 'flex', flexDirection: 'column', gap: 10,
        }}>
          <button
            onClick={() => { dispatch({ type: 'RESET' }); router.push('/') }}
            style={{
              width: '100%', padding: '17px 24px',
              background: '#C4614A', color: 'white',
              border: 'none', borderRadius: 16,
              fontFamily: "'DM Sans', sans-serif",
              fontSize: 16, fontWeight: 500, cursor: 'pointer',
              boxShadow: '0 4px 20px rgba(196,97,74,0.28)',
            }}
          >
            Make Another Pattern
          </button>
          <button
            onClick={handleDownload}
            style={{
              width: '100%', padding: '13px 24px',
              background: 'white', color: '#6B5744',
              border: '1.5px solid #E4D9C8', borderRadius: 16,
              fontFamily: "'DM Sans', sans-serif",
              fontSize: 14, cursor: 'pointer',
            }}
          >
            Download again
          </button>
        </div>
      </main>
    )
  }

  // ── Idle state (default) ──────────────────────────────────────────────────
  const styleLabel = patternData
    ? (STITCH_STYLE_META[patternData.meta.stitchStyle]?.label ?? patternData.meta.stitchStyle)
    : '—'

  return (
    <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: '#FAF6EF' }}>
      <Header />
      <StepIndicator />

      <div style={{
        flex: 1,
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        padding: '20px 28px 180px', textAlign: 'center',
      }}>
        <div style={{
          width: 96, height: 96, borderRadius: 28,
          background: 'linear-gradient(135deg, #F2EAD8, #E4D9C8)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 48, marginBottom: 24,
          boxShadow: '0 8px 32px rgba(44,34,24,0.10)',
        }}>
          📄
        </div>

        <h1 style={{
          fontFamily: "'Playfair Display', serif",
          fontSize: 28, fontWeight: 700,
          color: '#2C2218', lineHeight: 1.25, marginBottom: 10,
        }}>
          Your PDF is ready
        </h1>
        <p style={{
          fontSize: 14, color: '#6B5744', lineHeight: 1.7,
          maxWidth: 280, marginBottom: 28,
          fontFamily: "'DM Sans', sans-serif",
        }}>
          Your pattern PDF includes the full grid, colour key, and beginner instructions.
        </p>

        {/* Pattern summary */}
        {patternData && (
          <div style={{
            width: '100%', maxWidth: 320,
            background: 'white', borderRadius: 20,
            boxShadow: '0 2px 16px rgba(44,34,24,0.07)',
            padding: 16, marginBottom: 8,
          }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <SummaryTile label="Grid"     value={`${patternData.meta.width}×${patternData.meta.height}`} />
              <SummaryTile label="Colours"  value={String(patternData.meta.colorCount)} />
              <SummaryTile label="Stitches" value={patternData.meta.totalStitches.toLocaleString()} />
              <SummaryTile label="Style"    value={styleLabel} />
            </div>
          </div>
        )}

        {/* Error message */}
        {status === 'error' && error && (
          <div style={{
            marginTop: 16, padding: '12px 16px',
            background: 'rgba(196,97,74,0.08)',
            borderRadius: 12, maxWidth: 300,
          }}>
            <p style={{ fontSize: 13, color: '#C4614A', fontFamily: "'DM Sans', sans-serif" }}>
              {error}
            </p>
          </div>
        )}
      </div>

      {/* Bottom bar */}
      <div style={{
        position: 'fixed', bottom: 0, left: '50%',
        transform: 'translateX(-50%)',
        width: '100%', maxWidth: 430,
        padding: '16px 20px max(20px, env(safe-area-inset-bottom))',
        background: 'linear-gradient(to top, #FAF6EF 80%, transparent)',
        zIndex: 50, display: 'flex', flexDirection: 'column', gap: 10,
      }}>
        <button
          onClick={handleDownload}
          disabled={!patternData}
          style={{
            width: '100%', padding: '17px 24px',
            background: patternData ? '#C4614A' : '#E4D9C8',
            color: patternData ? 'white' : '#C8BFB0',
            border: 'none', borderRadius: 16,
            fontFamily: "'DM Sans', sans-serif",
            fontSize: 16, fontWeight: 500,
            cursor: patternData ? 'pointer' : 'not-allowed',
            boxShadow: patternData ? '0 4px 20px rgba(196,97,74,0.28)' : 'none',
          }}
        >
          ⬇ Download PDF
        </button>
        <button
          onClick={() => router.push('/preview')}
          style={{
            width: '100%', padding: '13px 24px',
            background: 'transparent', color: '#6B5744',
            border: '1.5px solid #E4D9C8', borderRadius: 16,
            fontFamily: "'DM Sans', sans-serif",
            fontSize: 14, cursor: 'pointer',
          }}
        >
          ← Back to preview
        </button>
      </div>
    </main>
  )
}
