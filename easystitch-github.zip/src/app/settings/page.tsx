'use client'

/**
 * app/settings/page.tsx
 *
 * Step 3: Pattern settings — stitch style, grid size, colour count.
 *
 * FIX #3 + #4: Was importing deleted STITCH_STYLE_LABELS and using old
 * stitch style values ('square', 'cross', 'bobble'). Now uses STITCH_STYLE_META
 * from constants and only shows available styles. Coming-soon styles are shown
 * greyed out with a badge so users know more is coming.
 *
 * FIX #5: "Generate Pattern" CTA now calls usePatternGeneration() before
 * navigating to /preview. Pattern is generated here so the preview page
 * receives real data.
 */

import { useRouter } from 'next/navigation'
import Header        from '@/components/layout/Header'
import StepIndicator from '@/components/ui/StepIndicator'
import BottomCTA     from '@/components/layout/BottomCTA'
import { usePattern }            from '@/context/PatternContext'
import { usePatternGeneration }  from '@/hooks/usePatternGeneration'
import { GRID_SIZES, STITCH_STYLE_META, MIN_COLORS, MAX_COLORS } from '@/lib/constants'
import { StitchStyle, GridSize } from '@/types/pattern'

// Icon per stitch style — keyed to the new union values
const STITCH_ICONS: Record<StitchStyle, string> = {
  graphghan:     '⬛',
  c2c:           '◪',
  singleCrochet: '▦',
  tapestry:      '⧉',
}

export default function SettingsPage() {
  const router  = useRouter()
  const { state, dispatch }        = usePattern()
  const { generate, isGenerating, error } = usePatternGeneration()
  const { settings } = state

  function setStitchStyle(style: StitchStyle) {
    dispatch({ type: 'UPDATE_SETTINGS', payload: { stitchStyle: style } })
  }

  function setGridSize(size: GridSize) {
    dispatch({ type: 'UPDATE_SETTINGS', payload: { gridSize: size } })
  }

  function setMaxColors(count: number) {
    dispatch({ type: 'UPDATE_SETTINGS', payload: { maxColors: count } })
  }

  // Generate the pattern, then navigate only if it succeeded.
  // generate() returns true on success, false on failure.
  // On failure, the error state from usePatternGeneration is set and
  // shown in the error card below.
  async function handleGenerate() {
    const succeeded = await generate()
    if (succeeded) router.push('/preview')
  }

  return (
    <main className="min-h-screen flex flex-col bg-cream-50">
      <Header />
      <StepIndicator />

      <section className="flex-1 flex flex-col px-6 pt-4 pb-44 gap-8">

        <div>
          <h1 className="font-display text-2xl text-ink mb-1">Pattern settings</h1>
          <p className="font-body text-sm text-ink/50">Customise how your pattern looks.</p>
        </div>

        {/* Stitch Style */}
        <div>
          <label className="font-body font-semibold text-sm text-ink mb-3 block">
            Stitch style
          </label>
          <div className="grid grid-cols-2 gap-3">
            {(Object.keys(STITCH_STYLE_META) as StitchStyle[]).map(style => {
              const meta      = STITCH_STYLE_META[style]
              const isActive  = settings.stitchStyle === style
              const available = meta.available

              return (
                <button
                  key={style}
                  onClick={() => available && setStitchStyle(style)}
                  disabled={!available}
                  className={[
                    'relative flex flex-col items-center gap-2 py-4 px-3 rounded-2xl border-2 transition-all font-body text-xs font-medium text-left',
                    isActive && available
                      ? 'border-rose-DEFAULT bg-rose-DEFAULT/5 text-rose-deep'
                      : available
                        ? 'border-cream-200 bg-white text-ink/60 hover:border-cream-300'
                        : 'border-cream-100 bg-cream-50 text-ink/25 cursor-not-allowed',
                  ].join(' ')}
                >
                  <span className="text-2xl">{STITCH_ICONS[style]}</span>
                  <span>{meta.label}</span>
                  <span className="text-[10px] opacity-60">{meta.description}</span>
                  {!available && (
                    <span className="absolute top-2 right-2 text-[9px] bg-cream-200 text-ink/40 px-1.5 py-0.5 rounded-full font-medium">
                      Soon
                    </span>
                  )}
                </button>
              )
            })}
          </div>
        </div>

        {/* Grid Size */}
        <div>
          <label className="font-body font-semibold text-sm text-ink mb-1 block">
            Grid size
          </label>
          <p className="font-body text-xs text-ink/40 mb-3">
            Larger grids have more detail but take longer to stitch.
          </p>
          <div className="grid grid-cols-3 gap-3">
            {GRID_SIZES.map(size => (
              <button
                key={size.label}
                onClick={() => setGridSize(size)}
                className={[
                  'flex flex-col items-center gap-1 py-4 rounded-2xl border-2 transition-all font-body',
                  settings.gridSize.label === size.label
                    ? 'border-rose-DEFAULT bg-rose-DEFAULT/5'
                    : 'border-cream-200 bg-white',
                ].join(' ')}
              >
                <span className={[
                  'font-semibold text-sm',
                  settings.gridSize.label === size.label ? 'text-rose-deep' : 'text-ink',
                ].join(' ')}>
                  {size.label}
                </span>
                <span className="text-xs text-ink/40">{size.width}×{size.height}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Max Colors */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <div>
              <label className="font-body font-semibold text-sm text-ink block">
                Number of colours
              </label>
              <p className="font-body text-xs text-ink/40">Fewer colours = simpler to stitch</p>
            </div>
            <span className="font-display text-3xl text-rose-DEFAULT">
              {settings.maxColors}
            </span>
          </div>

          <div className="flex gap-2 mb-4">
            {Array.from({ length: settings.maxColors }).map((_, i) => (
              <div
                key={i}
                className="flex-1 h-3 rounded-full bg-rose-soft/60"
                style={{ opacity: 1 - i * (0.8 / settings.maxColors) }}
              />
            ))}
          </div>

          <input
            type="range"
            min={MIN_COLORS}
            max={MAX_COLORS}
            value={settings.maxColors}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setMaxColors(Number(e.target.value))}
            className="w-full accent-rose-DEFAULT"
          />
          <div className="flex justify-between text-xs font-body text-ink/30 mt-1">
            <span>{MIN_COLORS} colours</span>
            <span>{MAX_COLORS} colours</span>
          </div>
        </div>

      </section>

      {/* Generation error — shown when generate() returns false */}
      {error && (
        <div className="px-6 pb-4">
          <div className="bg-rose-DEFAULT/8 border border-rose-DEFAULT/20 rounded-2xl px-4 py-3 flex gap-3 items-start">
            <span className="text-rose-DEFAULT text-lg leading-none mt-0.5">⚠️</span>
            <div>
              <p className="font-body font-medium text-sm text-rose-deep mb-0.5">
                Couldn't generate pattern
              </p>
              <p className="font-body text-xs text-rose-deep/70">
                {error}
              </p>
            </div>
          </div>
        </div>
      )}

      <BottomCTA
        primaryLabel="Generate Pattern"
        onPrimary={handleGenerate}
        isLoading={isGenerating}
        primaryDisabled={!state.rawImage && !state.patternData}
      />
    </main>
  )
}
