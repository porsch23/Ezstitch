'use client'

import { useRouter } from 'next/navigation'
import Header from '@/components/layout/Header'
import StepIndicator from '@/components/ui/StepIndicator'
import BottomCTA from '@/components/layout/BottomCTA'
import { usePattern } from '@/context/PatternContext'

export default function UploadPage() {
  const router = useRouter()
  const { state, dispatch } = usePattern()

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string
      dispatch({ type: 'SET_RAW_IMAGE', payload: dataUrl })
    }
    reader.readAsDataURL(file)
  }

  return (
    <main className="min-h-screen flex flex-col bg-cream-50">
      <Header />
      <StepIndicator />

      <section className="flex-1 flex flex-col items-center px-6 pt-4 pb-40">

        <div className="w-full max-w-sm text-center mb-8">
          <h1 className="font-display text-2xl text-ink mb-2">Upload your photo</h1>
          <p className="font-body text-sm text-ink/50">
            Pick any photo — a pet, portrait, flower, or scene.
          </p>
        </div>

        {/* Upload area */}
        <label
          htmlFor="photo-upload"
          className={[
            'w-full max-w-sm aspect-square rounded-3xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-all',
            state.rawImage
              ? 'border-transparent p-0 overflow-hidden'
              : 'border-cream-200 hover:border-rose-soft bg-white',
          ].join(' ')}
        >
          {state.rawImage ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={state.rawImage}
              alt="Uploaded photo"
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="flex flex-col items-center gap-3 p-8 text-center">
              <div className="w-16 h-16 rounded-2xl bg-cream-200 flex items-center justify-center text-3xl">
                📷
              </div>
              <p className="font-body font-medium text-ink/70 text-sm">
                Tap to choose a photo
              </p>
              <p className="font-body text-xs text-ink/30">
                JPG or PNG · From your camera roll or files
              </p>
            </div>
          )}
        </label>

        <input
          id="photo-upload"
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="sr-only"
          onChange={handleFileChange}
        />

        {/* Swap photo link */}
        {state.rawImage && (
          <label
            htmlFor="photo-upload"
            className="mt-4 text-sm font-body text-ink/40 underline cursor-pointer"
          >
            Choose a different photo
          </label>
        )}

      </section>

      <BottomCTA
        primaryLabel="Use This Photo"
        onPrimary={() => router.push('/enhance')}
        primaryDisabled={!state.rawImage}
      />
    </main>
  )
}
