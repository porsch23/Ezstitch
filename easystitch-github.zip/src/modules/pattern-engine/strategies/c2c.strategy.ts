/**
 * strategies/c2c.strategy.ts
 *
 * Placeholder for Corner-to-Corner (C2C) crochet strategy.
 *
 * ── What C2C is ───────────────────────────────────────────────────────────────
 * C2C builds a fabric from one corner diagonally to the opposite corner.
 * Each "cell" is a small granny square or dc-cluster worked on the diagonal.
 * The pattern is read along diagonal sweeps (d = row + col) rather than rows.
 *
 * ── How this strategy will differ from graphghan ──────────────────────────────
 *
 * 1. Grid assembly — SAME underlying Cell[][] data.
 *    The colour at each (row, col) is identical to graphghan.
 *    What changes is the traversal metadata and how instructions are generated.
 *
 * 2. Traversal order — DIAGONAL instead of rowByRow.
 *    The PDF and instruction renderer will use buildC2CTraversalOrder() to
 *    group cells into diagonals and number them for the pattern reader.
 *
 * 3. Cell shape — diamond / rotated square in renders.
 *    The stitchMapper / renderGrid must apply a 45° rotation to cell shapes.
 *    PatternData.meta.traversalOrder = 'diagonal' signals this to renderers.
 *
 * 4. Stitch count metadata — each diagonal has a count that rises then falls.
 *    e.g. for a 10×10 grid: 1,2,3...10,9,8...1 cells per diagonal.
 *    This is surfaced in the PDF "row guide" section.
 *
 * ── Implementation steps when ready ──────────────────────────────────────────
 * 1. Uncomment and complete execute() below
 * 2. Call buildC2CTraversalOrder() from gridBuilder.ts (already stubbed there)
 * 3. Add diagonal count to PatternMeta (extend the interface)
 * 4. Update renderGrid to handle traversalOrder === 'diagonal'
 * 5. Update the PDF grid renderer to draw rotated cells
 */

import { PatternData } from '@/types/pattern'
import { StitchStrategy, StrategyInput } from './types'

class C2CStrategy implements StitchStrategy {
  readonly id             = 'c2c' as const
  readonly displayName    = 'Corner to Corner'
  readonly description    = 'Diagonal stitch blocks — intermediate level'
  readonly traversalOrder = 'diagonal' as const

  execute(_input: StrategyInput): PatternData {
    // TODO: Implement C2C strategy
    // Steps:
    // 1. Build base grid (same as graphghan — colour per cell is identical)
    // 2. Annotate meta with traversalOrder: 'diagonal'
    // 3. Build diagonal traversal index via buildC2CTraversalOrder()
    //    and attach to meta for PDF renderer
    throw new Error(
      'C2C strategy is not yet implemented. Use graphghan in the meantime.'
    )
  }
}

export const c2cStrategy = new C2CStrategy()
