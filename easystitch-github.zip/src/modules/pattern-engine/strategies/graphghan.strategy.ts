/**
 * strategies/graphghan.strategy.ts
 *
 * The default strategy. Produces a standard graphghan (graph afghan) pattern:
 * a rectangular grid of filled square cells, one colour per cell, read
 * row-by-row from bottom-left to top-right (standard crochet direction).
 *
 * This is the simplest possible crochet graph pattern and the best
 * starting point for beginners. No colour-carry constraints, no diagonal
 * traversal — every cell is independent.
 *
 * Grid assembly logic previously in gridBuilder.ts lives here now.
 * gridBuilder.ts is kept as a shared utility for the buildGrid helper.
 */

import { PatternData, Cell, ColorEntry } from '@/types/pattern'
import { StitchStrategy, StrategyInput } from './types'
import { buildGrid, countStitchesPerColor } from '../gridBuilder'

class GraphghanStrategy implements StitchStrategy {
  readonly id            = 'graphghan' as const
  readonly displayName   = 'Simple Blocks'
  readonly description   = 'Filled square cells — great for beginners'
  readonly traversalOrder = 'rowByRow' as const

  execute(input: StrategyInput): PatternData {
    const { pixelGrid, palette, colorMap, settings } = input
    const { gridSize, stitchStyle } = settings

    // ── Build the 2D cell grid ──────────────────────────────────────────────
    // Standard graphghan: row 0 = top of image, left-to-right per row.
    // No constraints — any colour can appear in any cell.
    const grid: Cell[][] = buildGrid(colorMap, palette, gridSize.width, gridSize.height)

    // ── Annotate palette with stitch counts ────────────────────────────────
    const counts = countStitchesPerColor(colorMap, palette.length)
    const annotatedPalette: ColorEntry[] = palette.map((entry, i) => ({
      ...entry,
      stitchCount: counts[i],
    }))

    return {
      grid,
      palette: annotatedPalette,
      meta: {
        width:          gridSize.width,
        height:         gridSize.height,
        colorCount:     palette.length,
        stitchStyle,
        traversalOrder: this.traversalOrder,
        totalStitches:  gridSize.width * gridSize.height,
        generatedAt:    new Date().toISOString(),
      },
    }
  }
}

// Export a singleton — strategies are stateless, no need to instantiate per run
export const graphghanStrategy = new GraphghanStrategy()
