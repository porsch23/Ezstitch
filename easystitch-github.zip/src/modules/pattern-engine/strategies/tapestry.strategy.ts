/**
 * strategies/tapestry.strategy.ts
 *
 * Placeholder for Tapestry crochet strategy.
 *
 * ── What Tapestry crochet is ──────────────────────────────────────────────────
 * Tapestry crochet carries unused yarn strands across each row, working
 * over them so they're hidden inside the stitches. This means:
 *   - You never cut yarn between colour changes within a row
 *   - But: carrying many colours adds bulk and weight to the fabric
 *   - Practical limit: most tapestry projects carry max 2–3 yarns per row
 *
 * This is a hard technical constraint that graphghan ignores entirely.
 *
 * ── How this strategy differs from graphghan ─────────────────────────────────
 *
 * 1. Grid assembly — SAME base grid (colour per cell unchanged).
 *
 * 2. Row validation — POST-PROCESSING PASS required.
 *    After building the grid, scan each row for distinct colour count.
 *    Rows with > maxCarriedColors colours must be simplified:
 *      Option A: Merge minority colours to nearest dominant row colour (lossy)
 *      Option B: Flag rows and warn the user (lossless but manual)
 *    MVP should do Option B (warn). A later version can do auto-merge.
 *
 * 3. Traversal — rowByRow (same as graphghan), but PDF adds carry indicators.
 *    Each row in the PDF instruction guide shows which yarns are "carried".
 *
 * 4. Metadata — PatternMeta should include:
 *    - maxColoursPerRow: number (user configurable, default 2)
 *    - rowViolations: number[]  (row indices that exceed maxColoursPerRow)
 *
 * ── Implementation steps when ready ──────────────────────────────────────────
 * 1. Add maxCarriedColors to PatternSettings
 * 2. Add rowViolations to PatternMeta
 * 3. Implement validateAndSimplifyRows() — see stub below
 * 4. Call it after buildGrid(), attach violations to meta
 * 5. Update PDF renderer to show carry indicators per row
 */

import { PatternData, Cell } from '@/types/pattern'
import { StitchStrategy, StrategyInput } from './types'

class TapestryStrategy implements StitchStrategy {
  readonly id             = 'tapestry' as const
  readonly displayName    = 'Tapestry'
  readonly description    = 'Colour-carry technique — advanced'
  readonly traversalOrder = 'rowConstrained' as const

  execute(_input: StrategyInput): PatternData {
    // TODO: Implement tapestry strategy
    // Steps:
    // 1. Build base grid (same as graphghan)
    // 2. Run validateAndSimplifyRows() — see stub below
    // 3. Attach rowViolations to meta
    // 4. Return PatternData with traversalOrder: 'rowConstrained'
    throw new Error(
      'Tapestry strategy is not yet implemented. Use graphghan in the meantime.'
    )
  }
}

// ── Future implementation stubs ───────────────────────────────────────────────

/**
 * Scan each row and return indices of rows that carry more than
 * `maxCarried` distinct colours.
 *
 * TODO: Implement when tapestry strategy is activated.
 */
// function validateRows(grid: Cell[][], maxCarried: number): number[] {
//   return grid
//     .map((row, i) => ({ i, count: new Set(row.map(c => c.colorIndex)).size }))
//     .filter(r => r.count > maxCarried)
//     .map(r => r.i)
// }

/**
 * Simplify a row that violates the carry constraint by replacing minority
 * colour cells with the most frequent colour in that row.
 *
 * TODO: Implement when tapestry strategy is activated.
 * NOTE: This is lossy — subject clarity may degrade. Warn the user.
 */
// function simplifyRow(row: Cell[], maxCarried: number): Cell[] {
//   const freq = new Map<number, number>()
//   for (const cell of row) freq.set(cell.colorIndex, (freq.get(cell.colorIndex) ?? 0) + 1)
//   const dominant = [...freq.entries()]
//     .sort((a, b) => b[1] - a[1])
//     .slice(0, maxCarried)
//     .map(([idx]) => idx)
//   const dominantSet = new Set(dominant)
//   const fallback = dominant[dominant.length - 1]
//   return row.map(cell =>
//     dominantSet.has(cell.colorIndex) ? cell : { ...cell, colorIndex: fallback }
//   )
// }

export const tapestryStrategy = new TapestryStrategy()
