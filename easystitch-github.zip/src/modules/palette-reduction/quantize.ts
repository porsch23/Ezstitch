/**
 * palette-reduction/quantize.ts
 *
 * Implements median-cut colour quantization to reduce an image to N colours.
 *
 * Why median-cut?
 * - Deterministic (same input always produces same palette) — good for UX
 * - O(n log n) per split, manageable for 20×20 to 60×60 grids
 * - Produces perceptually balanced palettes without iterating like k-means
 *
 * Quality tradeoff:
 * - Median-cut can over-represent dominant regions (large sky, background wall)
 *   stealing palette slots from the subject.
 *   TODO (future): add subject-weighted sampling to bias palette toward centre pixels
 *
 * Clarity risk:
 * - With maxColors ≤ 3 on complex subjects, fine gradients collapse.
 * - Very similar colours (e.g. two near-identical skin tones) will be merged
 *   into one bucket — detail at edges will soften.
 */

import { PixelGrid, ColorEntry, ColorMap, LabColor, ColorBucket } from '@/types/pattern'
import { rgbToLab, labDistance, rgbToHex, perceivedLightness } from './colorUtils'
import { COLOR_SYMBOLS } from '@/lib/constants'

export interface QuantizeResult {
  palette:  ColorEntry[]
  colorMap: ColorMap    // flat array: index = pixel position, value = palette index
}

// ─── Step 1: Extract pixel samples ───────────────────────────────────────────

/**
 * Convert a PixelGrid to an array of LabColors.
 * Skips fully transparent pixels (alpha < 128).
 */
function extractLabPixels(grid: PixelGrid): LabColor[] {
  const pixels: LabColor[] = []
  for (let i = 0; i < grid.data.length; i += 4) {
    const r = grid.data[i]
    const g = grid.data[i + 1]
    const b = grid.data[i + 2]
    const a = grid.data[i + 3]
    if (a < 128) continue   // Skip transparent pixels
    pixels.push(rgbToLab(r, g, b))
  }
  return pixels
}

// ─── Step 2: Median-cut algorithm ────────────────────────────────────────────

/**
 * Find which LAB axis (L, a, b) has the largest range in this bucket.
 * We split along this axis to maximise colour separation per cut.
 */
function longestAxis(pixels: LabColor[]): 'L' | 'a' | 'b' {
  let minL = Infinity, maxL = -Infinity
  let minA = Infinity, maxA = -Infinity
  let minB = Infinity, maxB = -Infinity

  for (const p of pixels) {
    if (p.L < minL) minL = p.L
    if (p.L > maxL) maxL = p.L
    if (p.a < minA) minA = p.a
    if (p.a > maxA) maxA = p.a
    if (p.b < minB) minB = p.b
    if (p.b > maxB) maxB = p.b
  }

  const rangeL = maxL - minL
  const rangeA = maxA - minA
  const rangeB = maxB - minB

  if (rangeL >= rangeA && rangeL >= rangeB) return 'L'
  if (rangeA >= rangeB) return 'a'
  return 'b'
}

/**
 * Split a bucket into two halves by sorting along the longest axis
 * and cutting at the median.
 */
function splitBucket(bucket: ColorBucket): [ColorBucket, ColorBucket] {
  const axis = longestAxis(bucket.pixels)
  const sorted = [...bucket.pixels].sort((a, b) => {
    const av = axis === 'L' ? a.L : axis === 'a' ? a.a : a.b
    const bv = axis === 'L' ? b.L : axis === 'a' ? b.a : b.b
    return av - bv
  })
  const mid = Math.floor(sorted.length / 2)
  return [
    { pixels: sorted.slice(0, mid) },
    { pixels: sorted.slice(mid) },
  ]
}

/**
 * Recursively split buckets until we have `maxColors` buckets.
 * Always splits the largest bucket first to maximise colour diversity.
 */
function medianCut(pixels: LabColor[], maxColors: number): ColorBucket[] {
  let buckets: ColorBucket[] = [{ pixels }]

  while (buckets.length < maxColors) {
    // Find the largest bucket (most pixels) to split
    let largestIdx = 0
    for (let i = 1; i < buckets.length; i++) {
      if (buckets[i].pixels.length > buckets[largestIdx].pixels.length) {
        largestIdx = i
      }
    }

    const [left, right] = splitBucket(buckets[largestIdx])
    buckets.splice(largestIdx, 1, left, right)

    // Guard: if all buckets have 1 pixel we can't split further
    if (buckets.every(b => b.pixels.length <= 1)) break
  }

  return buckets
}

// ─── Step 3: Compute representative colour per bucket ────────────────────────

/**
 * Average all pixels in a bucket to get a representative RGB colour.
 * Averaging in LAB space would be more perceptually correct, but
 * averaging in RGB then converting is visually close enough for our use.
 */
function bucketAverageRgb(bucket: ColorBucket): { r: number; g: number; b: number } {
  let rSum = 0, gSum = 0, bSum = 0
  for (const p of bucket.pixels) {
    rSum += p.r
    gSum += p.g
    bSum += p.bl
  }
  const n = bucket.pixels.length
  return {
    r: Math.round(rSum / n),
    g: Math.round(gSum / n),
    b: Math.round(bSum / n),
  }
}

// ─── Step 4: Build the palette ────────────────────────────────────────────────

/**
 * Convert quantization buckets into a sorted ColorEntry palette.
 *
 * Symbols are assigned in perceived lightness order (dark → light)
 * so the darkest colour always gets the first symbol. This makes patterns
 * consistent and predictable for beginners reading the colour key.
 */
function buildPalette(buckets: ColorBucket[]): ColorEntry[] {
  const entries = buckets
    .filter(b => b.pixels.length > 0)
    .map(bucket => {
      const { r, g, b } = bucketAverageRgb(bucket)
      return { r, g, b, hex: rgbToHex(r, g, b), lightness: perceivedLightness(r, g, b) }
    })

  // Sort darkest → lightest for consistent symbol assignment
  entries.sort((a, b) => a.lightness - b.lightness)

  return entries.map((e, i) => ({
    hex:    e.hex,
    r:      e.r,
    g:      e.g,
    b:      e.b,
    symbol: COLOR_SYMBOLS[i] ?? String(i + 1),
    // label is undefined here — future: match against yarn colour database
  }))
}

// ─── Step 5: Assign each pixel to nearest palette colour ─────────────────────

/**
 * For each pixel in the grid, find the closest palette colour using LAB ΔE.
 * Returns a flat ColorMap (one index per pixel).
 *
 * Performance note: O(pixels × paletteSize). For 60×60 grid with 8 colours
 * that's 3600 × 8 = ~29k distance calculations — fast enough synchronously.
 * For larger future grids, this could be moved to a Web Worker.
 *
 * CROCHET-STYLE BRANCH (tapestry):
 * After building the colorMap, a post-processing pass would enforce
 * max-2-colours-per-row constraints by reassigning outlier cells to the
 * nearest row-dominant colour.
 */
function buildColorMap(grid: PixelGrid, palette: ColorEntry[]): ColorMap {
  const colorMap = new Uint8Array(grid.width * grid.height)
  const paletteLab = palette.map(e => rgbToLab(e.r, e.g, e.b))

  let pixelIdx = 0
  for (let i = 0; i < grid.data.length; i += 4) {
    const r = grid.data[i]
    const g = grid.data[i + 1]
    const b = grid.data[i + 2]
    const a = grid.data[i + 3]

    if (a < 128) {
      // Transparent pixel — assign to lightest palette colour (index: last)
      colorMap[pixelIdx] = palette.length - 1
    } else {
      const lab = rgbToLab(r, g, b)
      let bestIdx = 0
      let bestDist = Infinity
      for (let j = 0; j < paletteLab.length; j++) {
        const dist = labDistance(lab, paletteLab[j])
        if (dist < bestDist) {
          bestDist = dist
          bestIdx  = j
        }
      }
      colorMap[pixelIdx] = bestIdx
    }

    pixelIdx++
  }

  return colorMap
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Quantize a PixelGrid to at most `maxColors` colours.
 *
 * Returns:
 * - `palette`: sorted ColorEntry array (dark → light)
 * - `colorMap`: flat Uint8Array mapping pixel index → palette index
 */
export function quantizeImage(grid: PixelGrid, maxColors: number): QuantizeResult {
  if (maxColors < 1 || maxColors > 256) {
    throw new Error(`maxColors must be between 1 and 256, got ${maxColors}`)
  }

  const pixels  = extractLabPixels(grid)
  const buckets = medianCut(pixels, maxColors)
  const palette = buildPalette(buckets)
  const colorMap = buildColorMap(grid, palette)

  return { palette, colorMap }
}
